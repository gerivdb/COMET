# Test si YAML est accepté comme format de ressource
# Création d'un exemple YAML pour les workflows DEV COMET

import yaml
from datetime import datetime

# Configuration YAML pour DEV COMET workflows
yaml_config = {
    'dev_comet_workflows': {
        'version': '1.0',
        'updated': datetime.now().isoformat(),
        
        'ecosystem': {
            'name': 'gerivdb',
            'total_repos': 109,
            'monitored_repos': [
                {
                    'name': 'DevTools',
                    'language': 'PowerShell', 
                    'priority': 'critical',
                    'issues_open': 8,
                    'monitor_frequency': '4h'
                },
                {
                    'name': 'FLUENCE',
                    'language': 'Go',
                    'priority': 'critical', 
                    'description': 'Cognitive orchestrator',
                    'monitor_frequency': '2h'
                },
                {
                    'name': 'ECOYSTEM', 
                    'language': 'PowerShell',
                    'priority': 'high',
                    'issues_open': 1,
                    'monitor_frequency': '4h'  
                }
            ],
            'excluded_patterns': ['geri-cms-*', '*cms*']
        },
        
        'integrations': {
            'github_mcp': {
                'endpoints': [
                    'list_issues',
                    'get_repository', 
                    'list_commits',
                    'search_repositories'
                ],
                'rate_limits': {
                    'requests_per_hour': 5000,
                    'concurrent_max': 10
                }
            },
            
            'comet_browser': {
                'navigation_targets': [
                    'github.com/{owner}/{repo}',
                    'github.com/{owner}/{repo}/issues',
                    'github.com/{owner}/{repo}/commits'
                ],
                'extraction_selectors': {
                    'readme': 'article.markdown-body',
                    'issues': '.js-issue-row', 
                    'commits': '.commit-message'
                }
            },
            
            'perplexity_ai': {
                'models': ['sonar-pro', 'sonar'],
                'query_templates': [
                    'Latest {language} automation trends',
                    '{repo_name} GitHub analysis and insights',
                    'Best practices {language} DevOps workflows'
                ]
            },
            
            'notion_databases': {
                'ecosystem_monitor': {
                    'properties': [
                        'Repo_Name', 'Category', 'Language', 
                        'Status', 'Issues_Count', 'Priority'
                    ]
                },
                'workflow_automation': {
                    'properties': [
                        'Workflow_Name', 'Type', 'Target_Repos',
                        'Schedule', 'Status', 'Last_Run'
                    ]
                }
            }
        },
        
        'workflows': [
            {
                'name': 'monitor_critical_repos',
                'schedule': '0 */4 * * *',
                'targets': ['DevTools', 'FLUENCE', 'ECOYSTEM'],
                'actions': [
                    'github_mcp.list_issues',
                    'perplexity.analyze_trends', 
                    'notion.update_monitor'
                ],
                'filters': {
                    'exclude': ['geri-cms-*']
                }
            },
            {
                'name': 'ecosystem_research',
                'schedule': '0 9 * * 1',
                'targets': ['All_Non_CMS'],
                'actions': [
                    'perplexity.technology_research',
                    'comet.extract_repo_insights',
                    'notion.sync_findings'
                ]
            },
            {
                'name': 'cross_repo_analysis', 
                'schedule': 'manual',
                'targets': ['DevTools', 'FLUENCE'],
                'actions': [
                    'github_mcp.search_cross_references',
                    'perplexity.analyze_dependencies',
                    'notion.update_relationships'
                ]
            }
        ],
        
        'automation': {
            'error_handling': 'log_and_continue',
            'retry_policy': 'exponential_backoff',
            'notification_channels': ['notion', 'github_issues'],
            'backup_frequency': 'daily'
        }
    }
}

try:
    # Tentative de sauvegarde YAML
    yaml_content = yaml.dump(yaml_config, default_flow_style=False, allow_unicode=True, indent=2)
    
    with open('dev-comet-workflows.yaml', 'w', encoding='utf-8') as f:
        f.write(yaml_content)
    
    print("✅ YAML file created successfully!")
    print("📄 dev-comet-workflows.yaml - Configuration complete for DEV COMET")
    print("\n📋 YAML Content Preview:")
    print("=" * 50)
    print(yaml_content[:1000] + "..." if len(yaml_content) > 1000 else yaml_content)
    
except Exception as e:
    print(f"❌ YAML creation failed: {e}")
    print("💡 YAML may not be supported as resource format")

print(f"\n🎯 Summary of Generated Resources:")
print("📁 Markdown Files:")
print("  - Ecosystem-GitHub-gerivdb.md (repo inventory)")  
print("  - Instructions-DEV-COMET-Complete.md (updated instructions)")
print("\n📁 JSON Configuration Files:")
print("  - notion-databases-config.json (Notion DB schemas)")
print("  - github-mcp-config.json (GitHub MCP settings)")
print("  - comet-automation-config.json (Browser automation)")
print("  - perplexity-workflows-config.json (AI research)")
print("  - dev-comet-master-config.json (Master configuration)")
print("\n📁 YAML Workflow File (if supported):")
print("  - dev-comet-workflows.yaml (Complete workflow definitions)")
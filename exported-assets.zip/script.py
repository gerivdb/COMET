# Création des ressources JSON pour DEV COMET

import json
from datetime import datetime

# 1. Configuration Notion Databases
notion_databases = {
    "ecosystem_monitor": {
        "name": "Ecosystem Monitor gerivdb",
        "properties": {
            "Repo_Name": {
                "type": "title",
                "title": {}
            },
            "Category": {
                "type": "select",
                "select": {
                    "options": [
                        {"name": "DevTools", "color": "blue"},
                        {"name": "FLUENCE", "color": "purple"},
                        {"name": "ECOYSTEM", "color": "green"},
                        {"name": "IA/Research", "color": "orange"},
                        {"name": "Business/Metier", "color": "red"},
                        {"name": "Communication", "color": "yellow"},
                        {"name": "Automation", "color": "pink"},
                        {"name": "CMS/Lovable", "color": "gray"}
                    ]
                }
            },
            "Language": {
                "type": "multi_select",
                "multi_select": {
                    "options": [
                        {"name": "PowerShell", "color": "blue"},
                        {"name": "Python", "color": "green"},
                        {"name": "Go", "color": "purple"},
                        {"name": "TypeScript", "color": "orange"},
                        {"name": "HTML", "color": "red"}
                    ]
                }
            },
            "Status": {
                "type": "select",
                "select": {
                    "options": [
                        {"name": "Active", "color": "green"},
                        {"name": "Maintenance", "color": "yellow"},
                        {"name": "Archive", "color": "red"},
                        {"name": "New", "color": "purple"}
                    ]
                }
            },
            "Issues_Count": {
                "type": "number",
                "number": {"format": "number"}
            },
            "Size_KB": {
                "type": "number", 
                "number": {"format": "number"}
            },
            "Last_Update": {
                "type": "date",
                "date": {}
            },
            "Repo_URL": {
                "type": "url",
                "url": {}
            },
            "Description": {
                "type": "rich_text",
                "rich_text": {}
            },
            "Priority": {
                "type": "select",
                "select": {
                    "options": [
                        {"name": "Critical", "color": "red"},
                        {"name": "High", "color": "orange"}, 
                        {"name": "Medium", "color": "yellow"},
                        {"name": "Low", "color": "gray"}
                    ]
                }
            },
            "Integration_Type": {
                "type": "multi_select",
                "multi_select": {
                    "options": [
                        {"name": "GitHub_MCP", "color": "blue"},
                        {"name": "Comet_Browser", "color": "green"},
                        {"name": "Perplexity_Research", "color": "purple"},
                        {"name": "Manual_Only", "color": "gray"}
                    ]
                }
            }
        }
    },
    
    "workflow_automation": {
        "name": "DEV COMET Workflows",
        "properties": {
            "Workflow_Name": {"type": "title", "title": {}},
            "Type": {
                "type": "select",
                "select": {
                    "options": [
                        {"name": "GitHub_Sync", "color": "blue"},
                        {"name": "Research_Auto", "color": "purple"},
                        {"name": "Monitor_Issues", "color": "red"},
                        {"name": "Cross_Repo", "color": "orange"},
                        {"name": "Documentation", "color": "green"}
                    ]
                }
            },
            "Target_Repos": {
                "type": "multi_select", 
                "multi_select": {
                    "options": [
                        {"name": "DevTools", "color": "blue"},
                        {"name": "FLUENCE", "color": "purple"},
                        {"name": "ECOYSTEM", "color": "green"},
                        {"name": "BRAIN", "color": "orange"},
                        {"name": "All_Non_CMS", "color": "gray"}
                    ]
                }
            },
            "Schedule": {
                "type": "select",
                "select": {
                    "options": [
                        {"name": "Hourly", "color": "red"},
                        {"name": "Daily", "color": "orange"},
                        {"name": "Weekly", "color": "yellow"}, 
                        {"name": "Manual", "color": "gray"}
                    ]
                }
            },
            "Status": {
                "type": "select",
                "select": {
                    "options": [
                        {"name": "Running", "color": "green"},
                        {"name": "Paused", "color": "yellow"},
                        {"name": "Error", "color": "red"},
                        {"name": "Planned", "color": "blue"}
                    ]
                }
            },
            "Last_Run": {"type": "date", "date": {}},
            "Success_Rate": {"type": "number", "number": {"format": "percent"}},
            "Script_URL": {"type": "url", "url": {}},
            "Notes": {"type": "rich_text", "rich_text": {}}
        }
    }
}

# 2. Configuration GitHub MCP
github_mcp_config = {
    "primary_repos": [
        {
            "name": "DevTools",
            "owner": "gerivdb", 
            "repo": "DevTools",
            "language": "PowerShell",
            "priority": "Critical",
            "monitor_issues": True,
            "monitor_commits": True,
            "auto_sync_notion": True
        },
        {
            "name": "FLUENCE",
            "owner": "gerivdb",
            "repo": "FLUENCE", 
            "language": "Go",
            "priority": "Critical",
            "monitor_issues": True,
            "monitor_commits": True,
            "auto_sync_notion": True
        },
        {
            "name": "ECOYSTEM",
            "owner": "gerivdb",
            "repo": "ECOYSTEM",
            "language": "PowerShell", 
            "priority": "High",
            "monitor_issues": True,
            "monitor_commits": True,
            "auto_sync_notion": True
        },
        {
            "name": "BRAIN",
            "owner": "gerivdb",
            "repo": "BRAIN",
            "language": "Python",
            "priority": "High", 
            "monitor_issues": False,
            "monitor_commits": True,
            "auto_sync_notion": True
        },
        {
            "name": "email-sender-1",
            "owner": "gerivdb",
            "repo": "email-sender-1",
            "language": "PowerShell",
            "priority": "Medium",
            "monitor_issues": True,
            "monitor_commits": False,
            "auto_sync_notion": False
        }
    ],
    "exclusions": {
        "patterns": ["geri-cms-*", "*cms*"],
        "reason": "Lovable CMS projects - exclude from generic workflows"
    },
    "api_limits": {
        "requests_per_hour": 5000,
        "concurrent_requests": 10,
        "retry_policy": "exponential_backoff"
    }
}

# 3. Configuration Comet Browser
comet_config = {
    "navigation_patterns": {
        "repo_analysis": {
            "urls": [
                "https://github.com/{owner}/{repo}",
                "https://github.com/{owner}/{repo}/issues",
                "https://github.com/{owner}/{repo}/pulls", 
                "https://github.com/{owner}/{repo}/commits",
                "https://github.com/{owner}/{repo}/releases"
            ],
            "extract_selectors": {
                "readme_content": "article.markdown-body",
                "issues_list": ".js-issue-row",
                "commit_messages": ".commit-message",
                "repo_description": "[data-pjax='#repo-content-pjax-container'] p",
                "language_stats": ".BorderGrid-cell .Progress"
            }
        },
        "automation_scripts": {
            "weekly_repo_scan": {
                "schedule": "0 9 * * 1", 
                "targets": ["DevTools", "FLUENCE", "ECOYSTEM"],
                "actions": ["extract_readme", "count_issues", "latest_commits"]
            },
            "issue_monitoring": {
                "schedule": "0 */4 * * *",
                "targets": ["DevTools", "ECOYSTEM"],
                "actions": ["new_issues", "issue_updates", "priority_classification"]
            }
        }
    }
}

# 4. Workflows Perplexity
perplexity_workflows = {
    "ecosystem_research": {
        "queries": [
            "Latest developments in {language} automation tools",
            "{repo_name} GitHub repository analysis and insights", 
            "Best practices for {language} DevOps workflows",
            "Competitive analysis for {category} tools"
        ],
        "models": {
            "primary": "sonar-pro",
            "fallback": "sonar"
        },
        "output_format": "structured_with_citations"
    },
    "code_analysis": {
        "queries": [
            "Code quality analysis for {repo_url}",
            "Security review recommendations for {language} project",
            "Performance optimization suggestions for {repo_name}"
        ],
        "max_tokens": 2000,
        "temperature": 0.3
    }
}

# 5. Configuration intégrée DEV COMET
dev_comet_config = {
    "ecosystem": {
        "name": "gerivdb",
        "total_repos": 109,
        "monitored_repos": 5,
        "excluded_patterns": ["geri-cms-*"],
        "last_updated": datetime.now().isoformat()
    },
    "integrations": {
        "github_mcp": github_mcp_config,
        "comet_browser": comet_config, 
        "perplexity_ai": perplexity_workflows,
        "notion_databases": notion_databases
    },
    "automation": {
        "sync_frequency": "4h",
        "error_handling": "log_and_continue",
        "notification_channels": ["notion", "email"],
        "backup_strategy": "daily_snapshot"
    }
}

# Sauvegarde des fichiers JSON
configs = {
    "notion-databases-config.json": notion_databases,
    "github-mcp-config.json": github_mcp_config,
    "comet-automation-config.json": comet_config,
    "perplexity-workflows-config.json": perplexity_workflows,
    "dev-comet-master-config.json": dev_comet_config
}

for filename, config in configs.items():
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2, ensure_ascii=False, default=str)
    print(f"✅ Created {filename}")

print(f"\n🎯 Generated {len(configs)} configuration files for DEV COMET")
print("📁 All configs ready for import into your automation workflows")